<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrderLine extends Migration
{
    /**
     * Run the migrations.
     *orderslines
     * @return void
     */
    public function up()
    {
        Schema::create('lines', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->double('precio_libro');
            $table->integer('numUnidades');
            $table->string('nombre');
            $table->integer('book_id')->unsigned();
             $table->integer('order_id')->unsigned();
            $table->foreign('book_id')->references('id')->on('books')
->onDelete('cascade');
            $table->foreign('order_id')->references('id')->on('orders')
->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lines');
    }
}
