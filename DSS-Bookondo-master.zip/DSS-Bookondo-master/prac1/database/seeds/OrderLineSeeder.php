<?php

use Illuminate\Database\Seeder;

class OrderLineSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $elquijote = DB::table('books')->where('titulo', 'El Quijote')->first()->id;
        $lacelestina = DB::table('books')->where('titulo', 'La Celestina')->first()->id;
        $calles = DB::table('books')->where('titulo', '1775 Calles')->first()->id;
        $sabores = DB::table('books')->where('titulo', 'Sabores de siempre')->first()->id;

        DB::table('lines')->delete();
        DB::table('lines')->insert(
            [
                


            
                
            ]);
    }
}
