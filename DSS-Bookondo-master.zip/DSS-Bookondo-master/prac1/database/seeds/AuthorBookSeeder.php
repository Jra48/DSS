<?php

use Illuminate\Database\Seeder;

class AuthorBookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $emilio = DB::table('authors')->where('nombre', 'Emilio')->first()->id;
        $Jani = DB::table('authors')->where('nombre', 'Jani')->first()->id;
        $angel = DB::table('authors')->where('nombre', 'angel')->first()->id;

        $elquijote = DB::table('books')->where('titulo', 'El Quijote')->first()->id;
        $lacelestina = DB::table('books')->where('titulo', 'La Celestina')->first()->id;
        $calles = DB::table('books')->where('titulo', '1775 Calles')->first()->id;
        $sabores = DB::table('books')->where('titulo', 'Sabores de siempre')->first()->id;

        DB::table('author_book')->delete();
        DB::table('author_book')->insert(
            [
                [
                'book_id'=> $elquijote,
                'author_id'=> $emilio],

                ['book_id'=> $lacelestina,
                'author_id'=> $Jani],

                ['book_id'=> $lacelestina,
                'author_id'=> $angel],

                ['book_id'=> $calles,
                'author_id'=> $angel]
                   
            ]
        );

         
    }
}
