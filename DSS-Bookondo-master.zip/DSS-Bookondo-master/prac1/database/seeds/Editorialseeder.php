<?php

use Illuminate\Database\Seeder;

class Editorialseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('editorials')->delete();
        DB::table('editorials')->insert(
            [
                ['nombre' => 'Anaya',
                'telefono'=>619111222,
                'direccion'=>'La Huerta, nº6'],
                 ['nombre' => 'EditorialesManuela',
                'telefono'=>789121666,
                'direccion'=>'Palomos, nº72'],
                ['nombre' => 'Planeta',
                'telefono'=>981888112,
                'direccion'=>'Argentina, nº1'],
                ['nombre' => 'Santillana',
                'telefono'=>618546152,
                'direccion'=>'Fleming, nº2']
                
            ]
        );
    }
}
