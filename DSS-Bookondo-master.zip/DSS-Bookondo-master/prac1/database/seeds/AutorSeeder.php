<?php

use Illuminate\Database\Seeder;

class AutorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('authors')->delete();
        DB::table('authors')->insert(
            [
                ['nombre' => 'Emilio',
                'apellidos'=>'ALfonso',
                'fechanacimiento'=>'1/2/1992'],
                ['nombre' => 'Isabel',
                'apellidos'=>'Allende',
                'fechanacimiento'=>'6/7/1964'],
                ['nombre' => 'Mario',
                'apellidos'=>'Gaspar',
                'fechanacimiento'=>'21/12/1954'],
                ['nombre' => 'Emilio',
                'apellidos'=>'ALfonso',
                'fechanacimiento'=>'1/2/1992'],
                ['nombre' => 'Jani',
                'apellidos'=>'redondeo',
                'fechanacimiento'=>'1/2/1992'],
                ['nombre' => 'angel',
                'apellidos'=>'rivi',
                'fechanacimiento'=>'7/7/1982']
                
            ]
        );
    }
}
