<?php

use Illuminate\Database\Seeder;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $danisote = DB::table('users')->where('nombre', 'Danisote')->first()->id;
        

        DB::table('orders')->delete();
        DB::table('orders')->insert(
            [
                ['fecha'=>'02-04-2018',
                'calle'=>'Doctor Fleming',
                'localidad'=>'San Vicent',
                'precio_total' => 45.2,
                'precio_envio' => 3,
                'total' => 48.2,
                'user_id' => 1],
                ['fecha'=>'02-04-2018',
                'calle'=>'calle argentina',
                'localidad'=>'San Vicent',
                'precio_total' => 45.2,
                'precio_envio' => 3,
                'total' => 48.2,
                'user_id' => 2],
                ['fecha'=>'02-04-2018',
                'calle'=>'Doctor Fleming',
                'localidad'=>'Elche',
                'precio_total' => 45.2,
                'precio_envio' => 3,
                'total' => 48.2,
                'user_id' => 3],
                ['fecha'=>'02-04-2018',
                'calle'=>'el corral',
                'localidad'=>'Murcia',
                'precio_total' => 45.2,
                'precio_envio' => 3,
                'total' => 48.2,
                'user_id' => 4]

            

        
                
            ]);
    }
}
