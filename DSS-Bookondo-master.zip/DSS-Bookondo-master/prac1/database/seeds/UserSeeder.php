<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('users')->delete();
        DB::table('users')->insert(
            [
                ['nombre' => 'Danisote',
                'apellidos'=>'Pascual ParrONDO',
                'ncuenta'=>'999666999',
                'usuario'=>'DanishotBookondo',
                'email' => 'danilongi@gmail.com',
                'password' => Hash::make('libro123')],

               


        
                
            ]
        );
    }
}
