<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/librosrecomended', 'BookController@recomended');
Route::post('/search', 'BookController@search');

/*Libros mostrados, por tematica*/
Route::get('/todosloslibros', 'BookController@getAllBooks');
Route::get('/ficcion', 'BookController@getBooksFiccion');
Route::get('/cocina', 'BookController@getBooksCocina');
Route::get('/terror', 'BookController@getBooksTerror');
Route::get('/humor', 'BookController@getBooksHumor');
Route::get('/novela', 'BookController@getBooksNovela');





/*
Route::get('/', function () {
    return view('inicio');
});
Route::get('/home', function () {
    return view('inicio');
});*/

Route::get('/home', 'BookController@getTematica');

Route::get('/', 'BookController@getTematica');

Route::get('/contacto', function() {
    return view('contacto');
});


Route::group(['middleware' => 'auth'], function() {
Route::get('/verlibro/{id}', 'BookController@consultar');
Route::get('/datosmod', function() {
    return view('datosenvio');
});
Route::post('/datosenvio', 'OrderController@datosenvio');

//carro
Route::get('/mipedido/{id}/{orderid}', 'OrderController@pedidousuarioid'); //COnfirma pedido
Route::get('/lpedidosadmin/delete{id}', 'OrderlineController@borra'); // borra del carrito y del admin
Route::get('/addcarrito/{id}/{id2}', 'OrderlineController@add'); //carrito
Route::get('/lineaspedido/{id}', 'OrderlineController@muestra');
});


Route::group(['middleware' => 'admin'], function() {
Route::get('/admin', function() {
    return view('admin');
});
Route::get('/librosadmin', 'BookController@index');


Route::get('/librosadmin/delete{id}', 'BookController@borra');
Route::get('/librosadmin/pre', 'BookController@indexprecio');

Route::get('/autoresadmin', 'AuthorController@index');
Route::get('/autoresadmin/crear','AuthorController@create');
Route::get('/autoresadmin/delete{id}', 'AuthorController@borra');
Route::post('/autoresadmin','AuthorController@store');
Route::get('/autoresadmin/edit/{id}', 'AuthorController@preEdit');
Route::post('/autoresadmin/mod/{id}', 'AuthorController@edit');
Route::get('/autoresadmin/nombreasc', 'AuthorController@indexnameasc');

Route::get('/editorialesadmin', 'EditorialController@index');
Route::get('/editorialesadmin/crear', 'EditorialController@create');
Route::get('/editorialesadmin/delete{id}', 'EditorialController@borra');
Route::post('/editorialesadmin','EditorialController@store');
Route::get('/editorialesadmin/edit/{id}', 'EditorialController@preEdit');
Route::post('/editorialesadmin/mod/{id}', 'EditorialController@edit');
Route::get('/editorialesadmin/nombreasc', 'EditorialController@indexnameasc');

/*------------------- Libros ----------------------*/


Route::get('/librosadmin/priceasc', 'BookController@indexpriceasc');
Route::get('/librosadmin/pricedesc', 'BookController@indexpricedesc');
Route::get('/librosadmin/crear','BookController@create');
Route::post('/librosadmin','BookController@store');
Route::get('/librosadmin/edit/{id}', 'BookController@preEdit');
Route::post('/librosadmin/mod/{id}', 'BookController@edit');
/*------------------- Usuarios ----------------------*/

Route::get('/usuariosadmin', 'UserController@index');
Route::get('/usuariosadmin/crear', 'UserController@create');
Route::get('/usuariosadmin/delete{id}', 'UserController@borra');
Route::post('/usuariosadmin','UserController@store');
Route::get('/usuariosadmin/edit/{id}', 'UserController@preEdit');
Route::post('/usuariosadmin/mod/{id}', 'UserController@edit');
Route::get('/usuariosadmin/nombreasc', 'UserController@indexnameasc');

/*/pedidos*/
Route::get('/pedidosadmin', 'OrderController@index');
Route::get('/pedidosadmin/delete{id}', 'OrderController@borra');
Route::get('/pedidosadmin/asc', 'OrderController@indexasc');
Route::get('/lpedidosadmin', 'OrderlineController@index');

});


Auth::routes();

//Route::get('/home', 'HomeController@index');


Route::get('logout', function()
{
    Auth::logout();
    return Redirect::to('/');
});

Route::get('/admin', function() {
    return view('admin');
});

Route::get('/accesodenegado', function() {
    return view('sinpermiso');
});


//Route::get('/librosrecomended', 'OrderlineController@getIdUsuario');