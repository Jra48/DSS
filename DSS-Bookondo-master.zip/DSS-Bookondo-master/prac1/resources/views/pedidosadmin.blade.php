@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
	<a href="/pedidosadmin/asc"> Ordenar por fecha  </a>
	
</div>
<div class="panel-body">
	<table class= "table">
		<thread>


			<th class="doss">Num Pedido</th>
			<th class="doss">Fecha</th>
			<th class="doss">Calle</th>
			<th class="doss">Localida</th>
            <th class="doss">Precio Total</th>
            <th class="doss">Precio envio</th>
			<th class="doss">Total</th>
			<th class="doss">Id_usuario</th>
            <th class="doss">Accion 1</th>
            

		</thread>
		<tbody>
			@foreach ($pedidos as $pedido)
			<tr>
			
				<td class="table-text"><div class="">{{ $pedido->id }}</div></td>
				<td class="table-text"><div class="">{{ $pedido->fecha }}</div></td>
				<td class="table-text"><div class="">{{ $pedido->calle }}</div></td>
				<td class="table-text"><div class="">{{ $pedido->localidad }}</div></td>
                <td class="table-text"><div class="">{{ $pedido->precio_total }}</div></td>
                <td class="table-text"><div class="">{{ $pedido->precio_envio }}</div></td>
                <td class="table-text"><div class="">{{ $pedido->total }}</div></td>
                <td class="table-text"><div class="">{{ $pedido->user_id }}</div></td>

				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('OrderController@borra',$pedido) }}"> <div class="delete">Eliminar</div></a>
					
					
				</td></div></div></td>
				</div>
			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $pedidos->links() }}
	</div>
</div>
@endsection