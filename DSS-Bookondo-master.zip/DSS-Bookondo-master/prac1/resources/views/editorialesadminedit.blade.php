@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
	<form action="/editorialesadmin/mod/{{$editorial->id}}" method="POST" role="form">
    {{--<form action="{{ action}}" method="POST" role="form">--}}
    {{ csrf_field() }}

        <div class="form-group">
          <input type="text" class="form-control" id= "txtid" name="nombre"  value="{{$editorial->id}}" placeholder="Introduce nombre">
            <label for="">nombre</label>
            <input type="text" class="form-control" id= "txtnombre" name="nombre"  value="{{$editorial->nombre}}" placeholder="Introduce nombre">
        </div>

        <div class="form-group">
            <label for="">Teléfono</label>
            <input type="text" class="form-control" id="txttelefono" name="telefono"  value="{{$editorial->telefono}}" placeholder="Introduce telefono">
        </div>

        <div class="form-group">
            <label for="">Direccion</label>
            <input type="text" class="form-control" id="txtdireccion" name="direccion" value="{{$editorial->direccion}}" placeholder="Introduce direccion">
        </div>

        <button type="submit" class="btn btn-primary">Modificar editorial</button>

    </form>

@endsection