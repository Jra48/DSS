@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="offery">
		<div id="off1">
			<li><a href="#">HASTA UN 30% DE DESCUENTO EN LIBROS</a></li>
		</div>
		<div id="off2">
			<li><a href="#">ESPECIAL DÍA DE LA MADRE</a></li>
		</div>
		<div id="off3">
			<li><a href="#">LAS MEJORES OFERTAS</a></li>
		</div>
</div>
<div class="home-contacta">
    <div> Contacta con nosotros </div>
</div>
<div class="telefono-contacto">
    <img src= "imgBooks/telefono.png" width="140" height="140"/>
    <h4>¡Llámanos!</h4>
    <div>Si desea información sobre el servicio de compra, o si quiere conocer la situación de su
		pedido llame al teléfono <strong> 966304527 </strong> a su disposición los 365 días del año.
	</div>
</div>
<div class="email-contacto">
	 <img src= "imgBooks/email.png" width="140" height="140"/>
	 <h4>¡Envianos un email!</h4>
	 <div> También tenemos un servicio disponible de correo electrónico, por lo que también puedes
		 escribirnos al correo <u> bookondo.dss@gmail.com</u>, responderemos lo antes posible.
	 </div>
</div>
@endsection