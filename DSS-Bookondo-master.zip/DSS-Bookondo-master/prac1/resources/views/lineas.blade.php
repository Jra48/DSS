@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')

	
			@foreach ($lineas as $linea)
		
        <td class="table-title"><div class="col-tit">Libro : {{ $linea->nombre }}</div>
					
				</td>
                  <td class="table-title"><div class="col-tit">Precio : {{ $linea->precio_libro }}</div>
					
				</td>
                  <td class="table-title"><div class="col-tit">Pedido : {{ $linea->order_id }}</div>
				
                 	<td class="table-text"><div class="dos"><a href="{{ action('OrderlineController@borra',$linea) }}"> <u>Eliminar articulo</u></a></td></div></div></td>
                	-----------------------

				</td>

		
				
		
				</div>
			</tr>
			
			@endforeach
	
	

<div class="boxcreate">
	<a href="/mipedido/{{Auth::user()->id}}/{{$linea->order_id}}">Finalizar pedido</a>
</div>


		</tbody>
	</table>
</div>
@endsection