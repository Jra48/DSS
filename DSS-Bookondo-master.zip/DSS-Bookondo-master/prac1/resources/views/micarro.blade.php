@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
</div>
<div class="panel-body">
	
			
			
		
			Precio con iva includo : {{ $pedido->precio_total }} €<br/>
			Precion del envio : {{ $pedido->precio_envio }} <br/>
			Total : {{ $pedido->total }}<br/>
				
				---DATOS DEL ENVIO----<br/>
			Fecha del envio : {{ $pedido->fecha }} <br/>
			Direccion : {{ $pedido->calle }}<br/>
			Localidad : {{ $pedido->localidad }}<br/>
					
				</div>
			</tr>
		
		</tbody>
	</table>
	<div class="center">
		
	</div>
</div>
@endsection