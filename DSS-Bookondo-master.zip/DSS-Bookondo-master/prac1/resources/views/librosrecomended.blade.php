@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="offery">
		<div id="off1">
			<li><a href="#">HASTA UN 30% DE DESCUENTO EN LIBROS</a></li>
		</div>
		<div id="off2">
			<li><a href="#">ESPECIAL DÍA DE LA MADRE</a></li>
		</div>
		<div id="off3">
			<li><a href="#">LAS MEJORES OFERTAS</a></li>
		</div>
	</div>
<div class="home-title">
	<h1> RECOMENDADOS </h1>
</div>

<div class="home-subtitle">
	<li><a href="/">Home</a> - Libros recomendados</li>
</div>

<div class="panel-body-1">
	<table class= "librosrecomendados">
		<tbody>
			@foreach ($libros as $libro)
			<tr>
                <td class="table-image">
                    <div class="col-img"><img src= "imgBooks/{{$libro->urlImagen}}" width="100" height="150"/></div></td>
					
				<td class="table-title"><div class="col-tit">{{$libro->titulo}}</div>
					<div class="name-autor"> "aquí nombre del autor" </div>
				</td>
				<td class="table-price">
					<div class="verlibro-section">
							<div class="boxcreate">
								<a href="/verlibro/{{$libro->id}}"><span class="info-icon"><i class="icon icon-eye"></i></span>Ver</a>
							</div>
						</div>
					<div class="price"> Precio </div>
					<div class="col-pri">{{$libro->precio}} €</div>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
</div>
@endsection