@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
	<form action="/autoresadmin/mod/{{$autor->id}}" method="POST" role="form">
    {{--<form action="{{ action }}" method="POST" role="form">--}}
    {{ csrf_field() }}

        <div class="form-group">
            <label for="">Nombre</label>
            <input type="text" class="form-control" id= "" name="nombre" value="{{$autor->nombre}}" placeholder="Introduce nombre">
        </div>

        <div class="form-group">
            <label for="">Apellidos</label>
            <input type="text" id="" class="form-control" name="apellidos" placeholder="Introduce apellidos">
        </div>

        <div class="form-group">
            <label for="">Fecha de nacimiento</label>
            <input type="text" class="form-control" id="" name="fechanacimiento" placeholder="Introduce fechanacimiento">
        </div>

        <button type="submit" class="btn btn-primary">Modificar autor</button>

    </form>

@endsection