@extends('layouts.master')

<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('contenido')
<div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Panel heading</div>
  
  <!-- Table -->
  <table class="table">
    <th class="">Nombre</th>
			<th class="">Apellidos</th>
			<th class="">Fecha de nacimiento</th>
			<th class="">Accion 1</th>
			<th class="">Accion 2</th>
  </table>
  <tbody>
			@foreach ($autores as $autor)
			<tr>
			
				<td class="table-text"><div class="">{{ $autor->nombre }}</div></td>
				<td class="table-text"><div class="">{{ $autor->apellidos }}</div></td>
				<td class="table-text"><div class="">{{ $autor->fechanacimiento }}</div></td>
				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('AuthorController@borra',$autor) }}"> <div class="delete">Eliminar</div></a></td></div>
				<td class="table-text"><div class="boxcreate-modificar">
					<a href="/autoresadmin/edit/{{$autor['id']}}"> <div class="modificar">Modificar</div></a></td></div>

			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $autores->links() }}
	</div>
</div>
@endsection

@section('contenido')

@endsection