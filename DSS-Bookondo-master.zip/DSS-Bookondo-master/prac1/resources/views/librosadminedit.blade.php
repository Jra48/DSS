@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
	<form action="/librosadmin/mod/{{$libro->id}}" method="POST" role="form">
    {{ csrf_field() }}

        <div class="form-group">
            <label for="">Titulo</label>
            <input type="text" class="form-control" name="titulo" value="{{$libro->titulo}}" placeholder="Escriba el titulo">
        </div>

        <div class="form-group">
            <label for="">Precio</label>
            <input type="text" class="form-control" name="precio" value="{{$libro->precio}}" placeholder="Escriba el precio">
        </div>

        <div class="form-group">
            <label for="">Tematica</label>
            <input type="text" class="form-control" name="tematica" value="{{$libro->tematica}}" placeholder="Escriba la temática">
        </div>

        <div class="form-group">
            <label for="">Descripcion</label>
            <input type="text" class="form-control" name="descripcion" value="{{$libro->descripcion}}" placeholder="Escriba la descripcion">
        </div>

        <div class="form-group">
            <label for="">Cantidad</label>
            <input type="text" class="form-control" name="cantidad" value="{{$libro->cantidad}}" placeholder="Escriba la cantidad">
        </div>

        <div class="form-group">
            <label for="">Editorial id</label>
            <input type="text" class="form-control" name="editorial_id" value="{{$libro->editorial_id}}" placeholder="Escriba la id ed">
        </div>

        <div class="form-group">
            <label for="urlImagen">Imagen</label>
            <div class="sectionbusc">
                <input type="file" class="form-control" name="urlImagen" placeholder="Inserta la imagen" value="{{$libro->urlImagen}}" id="buscarobb">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Modificar libro</button>
    
    </form>
</body>
</html>
@endsection