@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')
{{ 'Inicio' }}
@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('navegacion')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
	<!--<li><a href="#">Otro enlace</a></li>-->
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
	<div class="offery">
		<div id="off1">
			<li><a href="#">HASTA UN 30% DE DESCUENTO EN LIBROS</a></li>
		</div>
		<div id="off2">
			<li><a href="#">ESPECIAL DÍA DE LA MADRE</a></li>
		</div>
		<div id="off3">
			<li><a href="#">LAS MEJORES OFERTAS</a></li>
		</div>
	</div>
	<div class="home-libros">
		<h1> LIBROS </h1>
		<div class="home-subtitle-inicio">
			<li><a href="/todosloslibros"<span class="info-icon"><i class="icon icon-book"></i></span>Todos los libros</a></li>
			<li><a href="/ficcion"<span class="info-icon"><i class="icon icon-book"></i></span>Libros de ficcion</a></li>
			<li><a href="/cocina"<span class="info-icon"><i class="icon icon-book"></i></span>Libros de cocina</a></li>
			<li><a href="/terror"<span class="info-icon"><i class="icon icon-book"></i></span>Libros de terror</a></li>
			<li><a href="/humor"<span class="info-icon"><i class="icon icon-book"></i></span>Libros de humor</a></li>
			<li><a href="/novela"<span class="info-icon"><i class="icon icon-book"></i></span>Novelas</a></li>
		</div>
	</div>
	<!-- Carousel-->

	<div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
		<!-- Overlay -->
		<div class="overlay"></div>

		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#bs-carousel" data-slide-to="0" class="active"></li>
			<li data-target="#bs-carousel" data-slide-to="1"></li>
		</ol>
		
		<!-- Wrapper for slides -->
		<div class="carousel-inner">
			<div class="item slides active">
			<div class="slide-1"></div>
			<div class="hero">
				<hgroup>
					<h1>Nuestros libros recomendados por los mejores</h1>        
					<h3>¿Has visto nuestros mejores libros?</h3>
				</hgroup>
				<div class="slider-buttom">
					<a href="/librosrecomended"> Descúbrelos </a>
				</div>
			</div>
			</div>
			<div class="item slides">
			<div class="slide-2"></div>
			<div class="hero">        
				<hgroup>
					<h1>Toda nuestra variedad de libros</h1>        
					<h3>Visita nuestro catálogo de libros!</h3>        
				</hgroup>       
				<div class="slider-buttom">
					<a href="/todosloslibros"> Lets go! </a>
				</div>
			</div>
			</div>
		</div> 
</div>




	<div class="home-destacados">
		<h1 class="section-title"> LIBROS DE FICCION <h1>
	</div>
	
	<div class="panel-body-inicio">
		<div class= "librosdeficcion">
			<div class="container">
				<div class="row">
					<div class="Carousel" data-items="1,2,3,4" data-slide="1" id="ResSlid1">
						<div class="btn-group">
  							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    							Categoria <span class="caret"></span>
  							</button>
							<ul class="dropdown-menu">
								<li><a href="/todosloslibros">Todos los libros</a></li>
								<li><a href="/librosrecomended">Recomendados</a></li>
							</ul>
							</div>
						<button class="btn btn-primary rightLst"><span class="glyphicon glyphicon-menu-right"></span></button>
						<button class="btn btn-primary leftLst"><span class="glyphicon glyphicon-menu-left"></span></button>
						
						<div class="Carousel-inner">
							@foreach ($ficcion as $libro)
							<div class="item">
								<div class="col-xs-12 col-sm-12 col-lg-12">
									<div class="lead">
										<img class="imgbooks" src="imgBooks/{{$libro->urlImagen}}"width="100" height="150"/>
									</div>
								</div>
								<li><a href="/verlibro/{{$libro->id}}">
									<div class="title-inicio"> {{$libro->titulo}} </div>
								</a>
								<div class="autor-inicio"> Autor del libro </div>
								<div class="price-inicio">{{$libro->precio}} €</div>
								<div class="verlibro-section">
						</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="home-destacados">
			<h1 class="section-title"> LIBROS DE COCINA <h1>
		</div>

		<div class= "librosdeficcion">
			<div class="container">
				<div class="row">
					<div class="Carousel" data-items="1,2,3,4" data-slide="1" id="ResSlid1">
						<div class="btn-group">
  							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    							Categoria <span class="caret"></span>
  							</button>
							<ul class="dropdown-menu">
								<li><a href="/todosloslibros">Todos los libros</a></li>
								<li><a href="/librosrecomended">Recomendados</a></li>
							</ul>
							</div>
						<button class="btn btn-primary rightLst"><span class="glyphicon glyphicon-menu-right"></span></button>
						<button class="btn btn-primary leftLst"><span class="glyphicon glyphicon-menu-left"></span></button>
						
						<div class="Carousel-inner">
							@foreach ($cocina as $libro)
							<div class="item">
								<div class="col-xs-12 col-sm-12 col-lg-12">
									<div class="lead">
										<img class="imgbooks" src="imgBooks/{{$libro->urlImagen}}"width="100" height="150"/>
									</div>
								</div>
								<li><a href="/verlibro/{{$libro->id}}">
									<div class="title-inicio"> {{$libro->titulo}} </div>
								</a>
								<div class="autor-inicio"> Autor del libro </div>
								<div class="price-inicio">{{$libro->precio}} €</div>
								<div class="verlibro-section">
						</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		</div>
	<div class="home-destacados">
		<h1 class="section-title"> LIBROS DE NOVELAS <h1>
	</div>
	<div class= "librosdeficcion">
		<div class="container">
				<div class="row">
					<div class="Carousel" data-items="1,2,3,4" data-slide="1" id="ResSlid1">
						<div class="btn-group">
  							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    							Categoria <span class="caret"></span>
  							</button>
							<ul class="dropdown-menu">
								<li><a href="/todosloslibros">Todos los libros</a></li>
								<li><a href="/librosrecomended">Recomendados</a></li>
							</ul>
							</div>
						<button class="btn btn-primary rightLst"><span class="glyphicon glyphicon-menu-right"></span></button>
						<button class="btn btn-primary leftLst"><span class="glyphicon glyphicon-menu-left"></span></button>
						
						<div class="Carousel-inner">
							@foreach ($novela as $libro)
							<div class="item">
								<div class="col-xs-12 col-sm-12 col-lg-12">
									<div class="lead">
										<img class="imgbooks" src="imgBooks/{{$libro->urlImagen}}"width="100" height="150"/>
									</div>
								</div>
								<li><a href="/verlibro/{{$libro->id}}">
									<div class="title-inicio"> {{$libro->titulo}} </div>
								</a>
								<div class="autor-inicio"> Autor del libro </div>
								<div class="price-inicio">{{$libro->precio}} €</div>
								<div class="verlibro-section">
						</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
	</div>
	<div class="home-destacados">
		<h1 class="section-title"> LIBROS DE TERROR <h1>
	</div>
	<div class="librosdeficcion">
		<div class="container">
				<div class="row">
					<div class="Carousel" data-items="1,2,3,4" data-slide="1" id="ResSlid1">
						<div class="btn-group">
  							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    							Categoria <span class="caret"></span>
  							</button>
							<ul class="dropdown-menu">
								<li><a href="/todosloslibros">Todos los libros</a></li>
								<li><a href="/librosrecomended">Recomendados</a></li>
							</ul>
							</div>
						<button class="btn btn-primary rightLst"><span class="glyphicon glyphicon-menu-right"></span></button>
						<button class="btn btn-primary leftLst"><span class="glyphicon glyphicon-menu-left"></span></button>
						
						<div class="Carousel-inner">
							@foreach ($terror as $libro)
							<div class="item">
								<div class="col-xs-12 col-sm-12 col-lg-12">
									<div class="lead">
										<img class="imgbooks" src="imgBooks/{{$libro->urlImagen}}"width="100" height="150"/>
									</div>
								</div>
								<li><a href="/verlibro/{{$libro->id}}">
									<div class="title-inicio"> {{$libro->titulo}} </div>
								</a>
								<div class="autor-inicio"> Autor del libro </div>
								<div class="price-inicio">{{$libro->precio}} €</div>
								<div class="verlibro-section">
						</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
	</div>
	<div class="home-destacados">
		<h1 class="section-title"> LIBROS DE HUMOR <h1>
	</div>
	<div class="librosdeficcion">
		<div class="container">
				<div class="row">
					<div class="Carousel" data-items="1,2,3,4" data-slide="1" id="ResSlid1">
						<div class="btn-group">
  							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    							Categoria <span class="caret"></span>
  							</button>
							<ul class="dropdown-menu">
								<li><a href="/todosloslibros">Todos los libros</a></li>
								<li><a href="/librosrecomended">Recomendados</a></li>
							</ul>
							</div>
						<button class="btn btn-primary rightLst"><span class="glyphicon glyphicon-menu-right"></span></button>
						<button class="btn btn-primary leftLst"><span class="glyphicon glyphicon-menu-left"></span></button>
						
						<div class="Carousel-inner">
							@foreach ($humor as $libro)
							<div class="item">
								<div class="col-xs-12 col-sm-12 col-lg-12">
									<div class="lead">
										<img class="imgbooks" src="imgBooks/{{$libro->urlImagen}}"width="100" height="150"/>
									</div>
								</div>
								<li><a href="/verlibro/{{$libro->id}}">
									<div class="title-inicio"> {{$libro->titulo}} </div>
								</a>
								<div class="autor-inicio"> Autor del libro </div>
								<div class="price-inicio">{{$libro->precio}} €</div>
								<div class="verlibro-section">
						</div>
							</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
	</div>
</div>
@endsection