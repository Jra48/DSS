@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="headformulario">
    <h3><b> AÑADIR USUARIO </b></h3>
</div>
<div class="formulario">
	<form action="{{ url('/datosenvio') }}" method="POST" role="form">
    {{ csrf_field() }}
    
    <form action="" method="POST" role="form">

        <div class="form-group">
            <label for="">calle</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="calle" placeholder="Escriba calle" id="buscarobb">
            </div>
        </div>
        <div class="form-group">
            <label for="">localidad</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="localidad" placeholder="Escriba la contraseña" id="buscarobb">
            </div>
        </div>
</div>
    <div id="borde">
        
       <button type="submit" class="btn btn-primary" id="addobject">Actualizar</button>
    </div>
    </form>

</body>
</html>
@endsection