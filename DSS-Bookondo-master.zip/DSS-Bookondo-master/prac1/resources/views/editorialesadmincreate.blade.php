@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="headformulario">
    <h3><b> AÑADIR EDITORIAL </b></h3>
</div>
<div class="formulario">
	<form action="{{ url('/editorialesadmin') }}" method="POST" role="form">
    {{ csrf_field() }}

    <form action="" method="POST" role="form">

        <div class="form-group">
            <label for="">Nombre</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="nombre" placeholder="Introduce nombre" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Teléfono</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="telefono" placeholder="Introduce telefono" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Direccion</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="direccion" placeholder="Introduce direccion" id="buscarobb">
            </div>
        </div>
</div>
        <div id="borde">
            <button type="submit" class="btn btn-primary" id="addobject">Añadir editorial</button>
        </div>
    </form>

@endsection