@extends('layouts.master')

<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
	<a href="/librosadmin/priceasc"> Ordenar por precio mas bajo  </a>
	<a href="/librosadmin/pricedesc"> Ordenar por precio mas alto </a>
</div>
<form action="/autoresadmin/" method="GET" class="navbar-form navbar-right" role="search" enctype="multipart/form-data">
	<div class="input group">
		<input type="text" id="buscarT" name="nombre" class="form-control" placeholder="Introduce el autor">
		<span class="input group-btn">
			<button class="btn btn-default" id="boton-search" type="submit">Buscar</button>
		</span>
	</div>
</form>
<div class="panel-body">
	<table class= "table">
			<th class="">Nombre</th>
			<th class="">Apellidos</th>
			<th class="">Fecha de nacimiento</th>
			<th class="">Accion 1</th>
			<th class="">Accion 2</th>
		<tbody>
			@foreach ($autores as $autor)
			<tr>
			
				<td class="table-text"><div class="">{{ $autor->nombre }}</div></td>
				<td class="table-text"><div class="">{{ $autor->apellidos }}</div></td>
				<td class="table-text"><div class="">{{ $autor->fechanacimiento }}</div></td>
				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('AuthorController@borra',$autor) }}"> <div class="delete">Eliminar</div></a></td></div>
				<td class="table-text"><div class="boxcreate-modificar">
					<a href="/autoresadmin/edit/{{$autor['id']}}"> <div class="modificar">Modificar</div></a></td></div>

			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $autores->links() }}
	</div>
</div>

<div class="boxcreate">
	<a href="/autoresadmin/crear">Crear nuevo autor</a>
</div>
@endsection