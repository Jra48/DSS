@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
<a href="/usuariosadmin/nombreasc">Ordenar por nombre  </a>
</div>
<div class="panel-body">
	<table class= "table">
		<thread>
			<th class="doss">Nombre</th>
			<th class="doss">Apellidos</th>
			<th class="doss">Numero de cuenta</th>
            <th class="doss">Usuario</th>
            <th class="doss">Contraseña</th>
			<th class="doss">Accion 1</th>
			<th class="doss">Accion 2</th>

		</thread>
		<tbody>
			@foreach ($users_books as $user_book)
			<tr>
				<td class="table-text"><div class="">{{ $user_book->valoracion }}</div></td>
			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $usuarios->links() }}
	</div>
</div>
<div class="boxcreate">
	<a href="/usuariosadmin/crear">Crear nuevo usuario</a>
</div>
@endsection