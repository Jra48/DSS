<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title> Librería Bookondo </title>
    </head>
    <body>
        <h1>Bookondo</h1>
        <img src="https://miedohablarenpublico.files.wordpress.com/2012/08/el-mejor-libro-sobre-cc3b3mo-hablar-en-pc3bablico.jpg?w=270&h=240" width="230" height="230"/>
        <br>
        <br>
        <p>
            <u> Integrantes </u>
            <br>
            <br>
            <?= 'Rivilla Arredondo, Javier' ?>
            <br>
            <?= 'Pascual Parrondo, Daniel' ?>
            <br>
            <?= 'Rivilla Arredondo, Angel' ?>
            <br>
        </p>
    </body> 
</html>