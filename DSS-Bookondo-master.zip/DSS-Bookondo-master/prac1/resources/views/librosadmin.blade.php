
@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
	<a href="/librosadmin/priceasc"> Ordenar por precio mas bajo  </a>
	<a href="/librosadmin/pricedesc"> Ordenar por precio mas alto </a>
</div>
<form action="/librosadmin/" method="GET" class="navbar-form navbar-right" role="search" enctype="multipart/form-data">
	<div class="input group">
		<input type="text" id="buscarT" name="tematica" class="form-control" placeholder="Introduce la tematica">
	
		<span class="input group-btn">
			<button class="btn btn-default" id="boton-search" type="submit">Buscar</button>
		</span>
	</div>
</form>

<div class="panel-body">
	<table class= "table">
			<thread>
				<th class="">Titulo</th>
				<th class="">Precio</th>
				<th class="">Tematica</th>
				<th class="">Descripcion</th>
				<th class="">Cantidad</th>
				<th class="">Accion 1</th>
				<th class="">Accion 2</th>
				<th class="">Imagen</th>
			</thread>
		<tbody>
			@foreach ($libros as $libro)
			<tr>
			
				<td class="table-text"><div class="">{{$libro->titulo}}</div></td>
				<td class="table-text"><div class="">{{$libro->precio}}</div></td>
				<td class="table-text"><div class="">{{$libro->tematica}}</div></td>
				<td class="table-text"><div class="">{{$libro->descripcion}}</div></td>
				<td class="table-text"><div class="">{{$libro->cantidad}}</div></td>

				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('BookController@borra',$libro) }}"> <div class="delete">Eliminar</div></a></td></div>
				
				<td class="table-text"><div class="boxcreate-modificar">
					<a href="/librosadmin/edit/{{$libro['id']}}"> <div class="modificar">Modificar</div></a></td></div>

				<td class="table-text"><div class="cinco"><img src= "/imgBooks/{{$libro->urlImagen}}" width="100" height="150"/></div></td>
			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $libros->links() }}
	</div>
</div>
<div class="boxcreate">
	<a href="/librosadmin/crear">Crear nuevo libro</a>
</div>
@endsection