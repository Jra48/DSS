@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="headformulario">
    <h3><b> AÑADIR USUARIO </b></h3>
</div>
<div class="formulario">
	<form action="{{ url('/usuariosadmin') }}" method="POST" role="form">
    {{ csrf_field() }}
    
    <form action="" method="POST" role="form">

        <div class="form-group">
            <label for="">Nombre</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="nombre" placeholder="Escriba el nombre" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Apellidos</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="apellidos" placeholder="Escriba los apellidos" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Numero de cuenta</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="ncuenta" placeholder="Escriba el nº cuenta" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Usuario</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="usuario" placeholder="Escriba el usuario" id="buscarobb">
            </div>
        </div>
        
        <div class="form-group">
            <label for="">Email</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="email" placeholder="Escriba la email" id="buscarobb">
            </div>
        </div>
        <div class="form-group">
            <label for="">Contraseña</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="password" placeholder="Escriba la contraseña" id="buscarobb">
            </div>
        </div>
</div>
    <div id="borde">
        
       <button type="submit" class="btn btn-primary" id="addobject">Añadir usuario</button>
    </div>
    </form>

</body>
</html>
@endsection