@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')
{{ 'Libros' }}
@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
	<form action="/usuariosadmin/mod/{{$usuario->id}}" method="POST" role="form">
    {{ csrf_field() }}
    
    <form action="" method="POST" role="form">

        <div class="form-group">
            <label for="">Nombre</label>
            <input type="text" class="form-control" name="nombre" value="{{$usuario->nombre}}" placeholder="Escriba el titulo">
        </div>

        <div class="form-group">
            <label for="">Apellidos</label>
            <input type="text" class="form-control" name="apellidos" value="{{$usuario->apellidos}}" placeholder="Escriba el precio">
        </div>

        <div class="form-group">
            <label for="">Numero de cuenta</label>
            <input type="text" class="form-control" name="ncuenta"  value="{{$usuario->ncuenta}}" placeholder="Escriba la temática">
        </div>

        <div class="form-group">
            <label for="">Usuario</label>
            <input type="text" class="form-control" name="usuario" value="{{$usuario->usuario}}" placeholder="Escriba la descripcion">
        </div>

        <div class="form-group">
            <label for="">Contraseña</label>
            <input type="text" class="form-control" name="contrasena" value="{{$usuario->contrasena}}" placeholder="Escriba la cantidad">
        </div>

        <button type="submit" class="btn btn-primary">Modificar usuario</button>
    
    </form>

</body>
</html>
@endsection