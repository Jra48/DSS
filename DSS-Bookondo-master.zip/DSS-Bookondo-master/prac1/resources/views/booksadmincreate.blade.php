@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="headformulario">
    <h3><b> AÑADIR LIBRO </b></h3>
</div>
<div class="formulario">
    <form action="{{ url('/librosadmin') }}" method="POST" role="form" enctype="multipart/form-data">
    {{ csrf_field() }}
    
    <form action="" method="POST" role="form">

        <div class="form-group">
            <label for="">Titulo</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="titulo" placeholder="Escriba el titulo" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Precio</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="precio" placeholder="Escriba el precio" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Tematica</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="tematica" placeholder="Escriba la temática" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Descripcion</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="descripcion" placeholder="Escriba la descripcion" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Cantidad</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="cantidad" placeholder="Escriba la cantidad" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="">Editorial id</label>
            <div class="sectionbusc">
                <input type="text" class="form-control" name="editorial_id" placeholder="Escriba la id ed" id="buscarobb">
            </div>
        </div>

        <div class="form-group">
            <label for="urlImagen">Imagen</label>
            <div class="sectionbusc">
                <input type="file" class="form-control" name="urlImagen" placeholder="Inserta la imagen" id="buscarobb">
            </div>
        </div>
</div>
        <div id="borde">
            <button type="submit" class="btn btn-primary" id="addobject">Añadir libro</button>
        </div>
    </form>
</body>
</html>
@endsection