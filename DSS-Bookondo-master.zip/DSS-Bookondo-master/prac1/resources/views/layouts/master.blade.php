<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bookondo</title>

	<link href="{{ URL::asset('css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{ URL::asset('css/menu.css')}}" rel="stylesheet" type="text/css">
	<link href="{{ URL::asset('css/fonts.css')}}" rel="stylesheet" type="text/css">	
</head>
<body>
	
	<header>
		<div>
			<div class="left-nav">
				<div class="logo">
					<li><a href="/">
						<img src="/imgBooks/bookondo.png" width="100%" height="60"/>
					</a></li>
				</div>
				<div class="Sidebar-title">
					Libros
				</div>
				<div class="Sidebar-categories">
					Actualidad
				</div>
				<div class="categories1">
					<li><a href="/librosrecomended"> Libros recomendados </a></li>
				</div>
				<div class="categories1">
					<li><a href="#"> Libros más vendidos </a></li>
				</div>
				<div class="categories1">
					<li><a href="#"> Libros de oferta</a></li>
				</div>
			</div>
			<div class="right-nav">
				<div id="buscador">
					<form action="{{ url('/search') }}" method="POST" role="form">
    {{ csrf_field() }}
    

   			 <form action="" method="POST" role="form">
					<input type="text" id="caja-buscar" name='dato' placeholder="Temática, nombre o editorial">
					<button type="submit" class="btn-btn-primary" id="addobject"><span class="glyphicon glyphicon-search"></span></button>
			</form>	
				</div>
				
				<div class="menu">
					<ul>
						<li><a href="/"><span class="primero"><i class="icon icon-home"></i></span>Inicio</a></li>
						<li><a href="/login"><span class="sexto"><i class="icon icon-bitcoin"></i></span>Iniciar sesion</a></li>
						<li><a href="/register"><span class="tercero"><i class="icon icon-doc-text"></i></span>Registrarse</a></li>
						@if( Auth::user() == NULL)
							<li><a href="/login"><span class="quinto"><i class="icon icon-user"></i></span>Mi Cuenta</a></li>
						@else
							<li><a href=""><span class="quinto"><i class="icon icon-user"></i></span> {{Auth::user()->usuario}}</a>
							<ul>
								<li><a href="/lineaspedido/{{$x = Auth::user()->id}}">Mis pedidos</a></li>
								<li><a href="/logout">Cerrar sesion</a></li>
							
							</ul>
							</li>
						@endif
						<li><a href="/contacto"><span class="cuarto"><i class="icon icon-mail"></i></span>Contacto</a></li>

						@if (Auth::user() == NULL)
						@else
						@if( Auth::user()->id == 1)
						<li><a href=""><span class="segundo"><i class="icon icon-book"></i></span>Administrar</a>
							<ul>
								<li><a href="/librosadmin">Libros</a></li>
								<li><a href="/autoresadmin">Autores</a></li>
								<li><a href="/editorialesadmin">Editoriales</a></li>
								<li><a href="/usuariosadmin">Usuarios</a></li>
								<li><a href="/pedidosadmin">Pedidos</a></li>
								<li><a href="/lpedidosadmin">Lineas Pedidos</a></li>
							</ul>
						</li>
						@else
						@endif
						@endif
					</ul>
				</div>
			</div>
		</div>
	</header>
	<div class="article">
		@yield('contenido')
	</div>

	<script src="js/jquery.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
	 integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
	crossorigin="anonymous"></script>
	<script src="js/starting.js"></script>
</body>
</html>