@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="title-login"> ¿Eres nuevo en Bokondo? </div>
                    <div>Te damos la bienvenida y te invitamos a crear tu cuenta en unos sencillos pasos. 
                    <strong>(*) Campo obligatorio</strong></div>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('nombre') ? ' has-error' : '' }}">
                            <label for="nombre" class="col-md-4-control-label-correo">Nombre*</label>

                            <div class="col-md-6">
                                <input id="text-md-6" type="text" class="form-control" name="nombre" value="{{ old('nombre') }}" required autofocus>

                                @if ($errors->has('nombre'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('nombre') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                          <div class="form-group">
            <label for="apellidos" class="col-md-4-control-label-correo">Apellidos*</label>
            <div class="col-md-4-control-label-correo">
                <input type="text" class="form-control" name="apellidos" id="text-md-6">
            </div>
        </div>
          <div class="form-group">
            <label for="ncuenta" class="col-md-4-control-label-correo" >Numero de cuenta*</label>
            <div class="col-md-4-control-label-correo">
                <input type="text" class="form-control" name="ncuenta" id="text-md-6">
            </div>
        </div>
          <div class="form-group">
            <label for="usuario" class="col-md-4-control-label-correo" >Usuario*</label>
            <div class="col-md-4-control-label-correo">
                <input type="text" class="form-control" name="usuario" id="text-md-6">
            </div>
        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4-control-label-correo">Correo electrónico*</label>

                            <div class="col-md-6">
                                <input id="text-md-6" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4-control-label-correo">Contraseña*</label>

                            <div class="col-md-6">
                                <input id="text-md-6" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4-control-label-correo">Confirmar contraseña*</label>

                            <div class="col-md-6">
                                <input id="text-md-6" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 ol-md-offset-4">
                                <button type="submit" class="btn-btn-primary">
                                    Crear cuenta
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
