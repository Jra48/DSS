@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
	<a href="/editorialesadmin/nombreasc">Ordenar por nombre  </a>
</div>
<div class="panel-body">
	<table class= "table">
		<thread>
			<th class="">Nombre</th>
			<th class="">Telefono</th>
			<th class="">Direccion</th>
			<th class="">Accion 1</th>
			<th class="">Accion 2</th>

		</thread>
		<tbody>
			@foreach ($editoriales as $editorial)
			<tr>
				<td class="table-text"><div class="">{{ $editorial->nombre }}</div></td>
				<td class="table-text"><div class="">{{ $editorial->telefono }}</div></td>
				<td class="table-text"><div class="">{{ $editorial->direccion }}</div></td>


				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('EditorialController@borra',$editorial) }}"> <div class="delete">Eliminar</div></a></td></div>
					
				<td class="table-text"><div class="boxcreate-modificar">
					<a href="/editorialesadmin/edit/{{$editorial['id']}}"> <div class="modificar">Modificar</div></a></td></div>
			</tr>
			@endforeach
		</tbody>
	</table>
	<div class="center">
		{{ $editoriales->links() }}
	</div>
</div>
<div class="boxcreate">
	<a href="/editorialesadmin/crear">Crear nuevo editorial</a>
</div>
@endsection