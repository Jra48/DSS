@extends('layouts.master')
<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')

	<p class="parrafo"> Titulo </p>
    @foreach ($libros as $libro)
	 <p>{{$libro['titulo']}} por {{$libro['precio']}} <a href="{{ action('BookController@borra',$libro) }}"> <u>Eliminar</u></a></p>
	
@endforeach
<a href="/librosadmin/crear">Crear nuevo libro</a>
@endsection

