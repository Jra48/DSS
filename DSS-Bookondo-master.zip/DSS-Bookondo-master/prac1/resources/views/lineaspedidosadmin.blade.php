@extends('layouts.master')



<!--con layout plantilla hacemos uso de nuestra plantilla base, no podemos escribir
nada anter o no renderizará la pantilla-->

<!--establecemos un título en la sección título que hemos definido
en nuestra plantilla base-->
@section('titulo')

@endsection

<!--establecemos nuestra navegación y añadimos otro elemento-->
@section('columna')
	<!--heredamos con parent lo que hay en la plantilla base
	pero añadimos otro elemento al menú-->
	@parent
<li><a href="/libros#">Tematica</a></li>
<li><a href="/libros#">Autor</a></li>
@endsection

<!--establecemos el contenido de la sección contenido de 
nuestra plantilla base-->
@section('contenido')
<div class="Busqueda">
	<a href="#"> Ordenar por precio mas bajo  </a>
	<a href="#"> Ordenar por precio mas alto </a>
</div>
<div class="panel-body">
	<table class= "table">
		<thread>
			<th class="doss">Nº Linea</th>
			<th class="doss">Precio libro</th>
			<th class="doss">Unidades</th>
			<th class="doss">Numero de pedido</th>
			<th class="doss">nombre</th>
			<th class="doss">Libro id</th>
			<th class="doss">Accion 1</th>
		</thread>
		<tbody>
			@foreach ($lpedidos as $lpedido)
			<tr>
				<td class="table-text"><div class="">{{ $lpedido->id }}</div></td>
				<td class="table-text"><div class="">{{ $lpedido->precio_libro }}</div></td>
				<td class="table-text"><div class="">{{ $lpedido->numUnidades }}</div></td>
				<td class="table-text"><div class="">{{ $lpedido->order_id }}</div></td>
                <td class="table-text"><div class="">{{ $lpedido->nombre }}</div></td>
			    <td class="table-text"><div class="">{{ $lpedido->book_id }}</div></td>

				<td class="table-text"><div class="boxcreate-delete">
					<a href="{{ action('OrderlineController@borra',$lpedido) }}"> <div class="delete">Eliminar</div></a>
					</td></div></div></td>
				
		
				</div>
			</tr>
			@endforeach
			

		</tbody>
	</table>
	<div class="center">
		{{ $lpedidos->links() }}
	</div>
</div>
@endsection