<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Author;
use App\Book;

class DataTest extends TestCase
{

    public function testBooksData()
    {
        
    }
}