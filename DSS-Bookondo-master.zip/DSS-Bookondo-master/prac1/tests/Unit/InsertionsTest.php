<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

use App\Author;
use App\Book;
use App\Editorial;

class InsertionsTest extends TestCase
{

    /*
        Test que comprueba inserciones de los datos de un autor
    */
    public function testAuthorInsert()
    {
        $autor = new Author();

        $autor->nombre = 'Oscar';
        $autor->apellidos = 'Wilde';
        $autor->fechanacimiento = 10/3/1865;
        $autor->save();

        $this->assertEquals($autor->nombre, 'Oscar');
        $this->assertEquals($autor->apellidos, 'Wilde');
        $this->assertEquals($autor->fechanacimiento, 10/3/1865);

        $autor->delete();
    }

    /*
        Test que comprueba inserciones de los datos de un libro
    */
    public function testBookInsert()
    {


        $libro = new Book();

        $libro->titulo = 'Redes de los computadores';
        $libro->precio = 5;
        $libro->tematica = 'Estudios';
        $libro->descripcion = 'Empezar a estudiar redes de los computadores';
        $libro->cantidad = 20;
        $libro->editorial_id = 3;

        $libro->save();

        $this->assertEquals($libro->titulo, 'Redes de los computadores');
        $this->assertEquals($libro->precio, 5);
        $this->assertEquals($libro->tematica, 'Estudios');
        $this->assertEquals($libro->cantidad, 20);

        $libro->delete();

    }

    /*
        Test que comprueba inserciones de los datos de un libro
    */
    public function testEditorialInsert()
    {
        $e = new Editorial();
        $e->nombre = 'Anaya';
        $e->telefono = 966304527;
        $e->direccion = 'narnia n101';
        $e->save();

        $this->assertEquals($e->nombre, 'Anaya');
        $this->assertEquals($e->telefono, 966304527);
        $this->assertEquals($e->direccion, 'narnia n101');
        
        $e->delete();
    }
}
