<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

use App\Author;
use App\Book;
use App\Editorial;

class AssociationsTest extends TestCase
{
    /*
        Creamos un usuario y un libro
    */
    public function testUserBook()
    {
        $user = new User();
        $libro1 = new Book();
        $libro2 = new Book();

        $autor->nombre = 'Oscar';
        $autor->apellidos = 'Wilde';
        $autor->fechanacimiento = 10/3/1865;
        $autor->save();

        $libro1->titulo = 'Redes de los computadores';
        $libro1->precio = 5;
        $libro1->tematica = 'Estudios';
        $libro1->descripcion = 'Empezar a estudiar redes de los computadores';
        $libro1->cantidad = 20;
        $libro1->editorial_id = 3;
        $libro1->save();

        $libro2->titulo = 'Dss: Conocimientos básicos de PHP';
        $libro2->precio = 10;
        $libro2->tematica = 'Estudios';
        $libro2->descripcion = 'Empezar a estudiar diseño de software';
        $libro2->cantidad = 5;
        $libro2->editorial_id = 1;
        $libro2->save();

        $autor->books()->attach($libro1);
        $libro2->authors()->attach($autor);

    
        $this->assertEquals($libro1->author->nombre, 'Oscar');
        $this->assertEquals($autor->books[0]->titulo, 'Redes de los computadores');
        $this->assertEquals($libro2->author->nombre, 'Oscar');
        $this->assertEquals($autor->books[1]->titulo, 'Dss: Conocimientos básicos de PHP');

        $autor->delete();
        $libro1->delete();
        $libro2->delete(); 
    }

    public function testEditorialBook(){

        /*
            Creamos una editorial y un libro y le asignamos al libro una editorial
        */
        $editorial = new Editorial();
        $editorial2 = new Editorial();
        
        $editorial->nombre = 'Imprenta de Juan de la Cuesta';
        $editorial->telefono = 601272902;
        $editorial->direccion = 'Martinez Campos';
        $editorial->save();

        $editorial2->nombre = 'Imprenta Cervantina';
        $editorial2->telefono = 601342510;
        $editorial2->direccion = 'Calle Valencia n201';
        $editorial2->save();

        $libro1 = new Book();
        $libro1->titulo = 'Don Quijote de la Mancha';
        $libro1->precio = 20;
        $libro1->tematica = 'Novela de Aventuras';
        $libro1->descripcion = 'Obra más destacada de literatura española';
        $libro1->cantidad = 50;
        $libro1->editorial_id = 3;

        $libro2 = new Book();
        $libro2->titulo = 'Luces de bohemia';
        $libro2->precio = 20;
        $libro2->tematica = 'Comedia';
        $libro2->descripcion = 'Visión crítica y grotesca de la España';
        $libro2->cantidad = 25;
        $libro2->editorial_id = 2;

        $libro3 = new Book();
        $libro3->titulo = 'El Lazarillo de Tormes';
        $libro3->precio = 15;
        $libro3->tematica = 'Novela';
        $libro3->descripcion = 'Esbozo irónico y despiadado de la sociedad del momento';
        $libro3->cantidad = 10;
        $libro3->editorial_id = 3;

        $libro2->editorial()->associate($editorial2);
        $libro2->save();

        $editorial->books()->saveMany([
            $libro1, $libro3
        ]);
    
        $this->assertEquals($libro1->editorial->nombre, 'Imprenta de Juan de la Cuesta');
        $this->assertEquals($editorial->books[0]->titulo, 'Don Quijote de la Mancha');
        $this->assertEquals($libro2->editorial->nombre, 'Imprenta Cervantina');
        $this->assertEquals($editorial2->books[0]->titulo, $libro2->titulo);
        $this->assertEquals($libro3->editorial->nombre, 'Imprenta de Juan de la Cuesta');
        $this->assertEquals($editorial->books[1]->titulo, 'El Lazarillo de Tormes');

        $editorial->delete();
        $libro1->delete();
        $libro2->delete();
        $libro3->delete();
    }
}
